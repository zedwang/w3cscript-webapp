function LGY(a,s,w,f,p,l,t){
		var url=document.URL;
		var firstload='';
		var para=url.substring(url.indexOf("?")+1,url.length);
		this.param = para.substring(para.indexOf("&")+1,para.length);
		this.appname=a;
		this.server=s;
		this.weburl=w;
 		this.pagesize=p;
		this.loadtext=l;
		this.target = t;
		this.firstload=f;
		$('.sitename').html(this.appname);
		$('#forPc').attr('href',this.server);
		document.title=this.appname;
		if(this.target){
 			this.target = ' target=_blank ';
		}
 		this.getvar=function(key){
			return localStorage.getItem(key);
		},
		this.setcookie=function(k,v){
			if(v==null){
				localStorage.removeItem(k);
				return;
			}
			localStorage.setItem(k,v);
		},
		alertInfo=function(s){
		
			alert(s);
		},
		this.loading=function(){
			 //加载中
		},
		this.getjson = function(u,c,q){
				var arr = c.split(":");
				var btnOrnot = q ? q.indexOf("sub"):-1; 
				if( btnOrnot >= 0){
					 $('#'+q).attr('disabled',true);
				}
				if(q=='loading' && arr[1]!='refresh')this.loading();
				if(u.indexOf('http://')<0)u=this.server+u;
				$.ajax({
					url : u,
					type:'GET',
					async:false,   
					dataType : 'jsonp',
					jsonp:"jsoncallback",
					jsonpCallback:"getCallListReturn"+arr[0],
					success : function(json){
						//$.mobile.loading( "hide" );
						if(json){
							window[arr[0]](json,arr[1],arr[2],arr[3],arr[4]);
							if(btnOrnot >= 0){
								 $('#'+q).removeAttr('disabled'); 
							}
						}else{
							alertInfo('网络不给力',10,'error');	
						}
					 },
					error:function(){
						//$.mobile.loading( "hide" );
						 if(q=='alert'){
							 alertInfo('网络不给力');		
						 }
					 }
			 });	
		}

}

$(function(){  
	var url=document.URL;
 	var para=url.substring(url.indexOf("?")+1,url.length);
	var param =  para.substring(para.indexOf("&")+1,para.length);
 	if(para.lastIndexOf("#") >= 0)para=para.substring(0, para.lastIndexOf('#'));
    var action="",query='';
	if(para.indexOf("=")>0){
			if(para){
				arr=para.split("&");
			}
			if(arr[0].split("=")[1]){
					action = arr[0].split("=")[0];
					query = arr[0].split("=")[1];
			}
 			  if(action=='action'){
					switch(query){
						case 'viewText':
							lgy.getjson('e/api/getNewsContent.php?'+param,'Lgy_newstext_fun','loading');
							$('#lgy-back-home').attr('href','javascript:history.go(-1)').html('<i class="icon-chevron-left icon-large"></i>');
							$('.headername').html('正文');
							break;
						case 'viewPl':
							lgy.getjson('e/api/getNewsPl.php?'+param+'&pageSize=5','lgy_pl_view_all');
							break;
						case 'reg':
							 
							break;
						default:
							return;
					}
				}
	   }else{
	       lgy.getjson('e/api/getNewsList.php?'+lgy.firstload,'newslist');
	   }
	   lgy.getjson('e/api/getNewsClass.php','lgy_news_class');//请求获取栏目信息
	   //返回顶部
		$(".totop").hide();
		$(function(){
			$(window).scroll(function(){
				if ($(window).scrollTop()>100){
					$(".totop").fadeIn();
				}else{
					$(".totop").fadeOut();
				}
			});
			$(".totop").click(function(){
				$('body,html').animate({scrollTop:0},500);
				return false;
			});
		});
});
//获取网站栏目列表
function lgy_showList(cid,table,tbname,param){
  var r = 'table='+table+'&classid='+cid;
  $('.headername').html(tbname);
  lgy.getjson('e/api/getNewsList.php?table='+table+'&classid='+cid,'newslist:'+table+':'+table+cid+':'+tbname+':'+r,'loading');
}
function lgy_news_class(data,query,table){
 	if(data.code=='success'){ 
		$('#lgy_class_menu').empty();
 		var str='';
		for(i=0;i<data.result.length;i++){
 			var json=data.result[i].bclass;
			var dropdrow='';
			var haveson=''
			if(data.result[i].sonclass.length>0){
				dropdrow = '<i class="icon-caret-right"></i>';
			}else{
				haveson='lgy_showList('+json.bclassid+',\''+json.tbname+'\',\''+json.bclassname+'\');';
			}
			str = '<dt  onclick="showHideClass(\''+json.tbname+json.bclassid+'\',this)">'+dropdrow+'<span class="title "><a href="javascript: '+haveson+'">'+json.bclassname+'</a></span></dt><dd><ul class="sonlist" id="'+json.tbname+json.bclassid+'" ></ul></dd>';
			$('#lgy_class_menu').append(str);
            if(data.result[i].sonclass.length<1){
				$('#'+json.tbname+json.bclassid).remove();
			}
			var son='';
			for(a=0;a<data.result[i].sonclass.length;a++){
				var j = data.result[i].sonclass[a];
				son = '<li><a onclick="lgy_showList('+j.classid+',\''+j.tbname+'\',\''+j.classname+'\')">'+j.classname+'</a></li>';
				$('#'+json.tbname+json.bclassid).append(son);
			}
 		}
	}else{
	   alertInfo(data.info);
	}
} 
function showHideClass(id,e){
	$('#'+id).toggle();
    var i=$(e).children('i');
	if(i.hasClass("icon-caret-right")){
		i.removeClass("icon-caret-right");
		i.toggleClass("icon-caret-down");
	}else{
	    i.removeClass("icon-caret-down");
		i.toggleClass("icon-caret-right");
	}
}
//获取网站标题列表
function newslist(data,query,table,tbname,request){
	if(data.code=='success'){ 
		$('#lgy_class_menu').slideUp();
		$('#otherlink').hide();
		var str='';
        if(data.result==''){
			alertInfo('当前栏目暂无任何信息');
			$('.headername').html('');
			return
		}
		for(i=0;i<data.result.length;i++){
		    if(data.result[i].length>0){
			    for(j=0;j<data.result[i].length;j++){
					var json=data.result[i][j];
					var minheight = '';
					if(json.titlepic && (json.titlepic).indexOf('http')<0){
						json.titlepic=lgy.server+json.titlepic;
					}
					var str = str +'<div class="list-sum">';
					if(json.titlepic){
							var width='width="80px"';
							if(table=='coin'){
							   width='';
							}
							str += '<img src="'+json.titlepic+'" style="float:left;margin-right:8px" '+width+' height="55px" />';
							minheight = 'minheight';
					}else{
							minheight = '';
					}
					json.titlepic='';
					var str = str + '<h6><a '+lgy.target+' href="?action=viewText&classid='+json.classid+'&id='+json.id+'">'+json.title+'</a></h6><p class="'+minheight+'" style="font-size:12px">'+json.smalltext+'<span class="fr">'+json.plnum+'跟帖</span></p></div>';	
			    }
				var id='lgy-'+table;
				if(query=='page'){
					$('#_'+id).append(str);
				}else if(query=='refresh'){
					 $('#_'+id).html(str);
				}else{
					 
					 $('#panelArea').html("<div id='_"+id+"'></div>");
					 $('#_'+id).html(str);
					 $('#pagenation').html("<div id='_"+table+"-page'></div>");

				}
				loadmore(data,'_'+table+'-page',table,request);
		  }
		}
	}else{
	 alertInfo(data.info);
	
	}
}
function newslist_fun(data){
		if(data){
			for(i=0;i<data.result.length;i++){
				var json=data.result[i];
				if(json==null)continue;
				 var template =	'<div class="list-box lgy-list-title"  id="list-'+i+'"><h3 onclick="lgy_showList('+json[0].classid+',\''+json[0].table+'\',\''+json[0].classname+'\');" class="list-title">'+json[0].classname+'</h3></div>';
						$("#list-index").append(template);	
						  var str='';
						  for(j=0;j<data.result[i].length;j++){
							var json=data.result[i][j];
							var minheight = '';
							if(json.titlepic && (json.titlepic).indexOf('http')<0){
								json.titlepic=lgy.server+json.titlepic;
							}
							var str = str +'<div class="list-sum">';
							if(json.titlepic){
									var width='width="80px"';
									if(json.table=='coin'){
									   width='';
									}
									str += '<img src="'+json.titlepic+'" style="float:left;margin-right:8px" '+width+' height="55px" />';
									minheight = 'minheight';
							}else{
									minheight = '';
							}
							json.titlepic='';
							var str = str + '<h6><a '+lgy.target+' href="?action=viewText&classid='+json.classid+'&id='+json.id+'">'+json.title+'</a></h6><p class="'+minheight+'" style="font-size:12px">'+json.smalltext+'<span class="fr">'+json.plnum+'跟帖</span></p></div>';	
							 $("#list-"+i).append(str);
							 str='';
						  }
				}
		}else{
			alertInfo('获取信息列表失败！');
		}
}
/***获取新闻正文***/
function Lgy_newstext_fun(data){
	if(data.code=='success'){
		json=data.result.content;
		var id='content_'+json.classid+'_'+json.id;
		document.title=json.title;
		var str='<h4 style="margin-top:15px">'+json.title+'</h4>';
					str +=  '<div class=\"newsinfo\">'+json.classname+'&nbsp;&nbsp;'+json.newstime+' 浏览：'+json.onclick+'</div>';
					str +=  '<div class="newstext lgy_newstext">'+json.newstext+'</div>';

		var header='<div data-role="header" data-position="fixed"><a data-rel="back" class="ui-btn ui-btn-left ui-alt-icon ui-nodisc-icon ui-corner-all ui-btn-icon-notext ui-icon-back">Back</a><h1></h1><a class="pl_rihgt_num pull-right button" onclick="Lgy_pl_view_all('+json.classid+','+json.id+');">'+json.plnum+'跟帖</a></div>';

        $('#panelArea').html(str);
 		$('#lgy-plnum').html('<a href="?action=viewPl&'+lgy.param+'#lgy_all_pl">'+json.plnum+'跟帖</a>');
		var str = '';
		if(data.result.otherLink!=null){
			$('#otherlink').show();
			for(i=0;i<data.result.otherLink.length;i++) //获取相关阅读
			{
			  var j=data.result.otherLink[i];
 				$('#otherlink').append('<li><a '+lgy.target+' href="'+lgy.weburl+'?action=viewText&classid='+j.classid+'&id='+j.id+'"><i class="icon-caret-right"></i> '+j.title+'</a></li>');
			}
 		}
		lgy.setcookie('shareInfo',json.title+'_&_'+json.titleurl+'_&_'+json.smalltext+'_&_'+json.titlepic); //保存待分享数据
 	}else{
		alertInfo(data.info);
	}
}
/***翻页加载***/
 function loadmore(data,showid,table,param){  
	if(data.total>lgy.pagesize){
 		$('#'+showid).html('<button class="button" style="display:block;width:100%;margin:10px auto" id="sub-'+showid+'" onclick="nextPage('+(data.pageIndex+1)+',\''+showid+'\',\''+table+'\',\''+param+'\')" data-page=0>显示下'+lgy.pagesize+'条</button>');
        $('#sub-'+showid).attr('data-page',(data.pageIndex+1));
		var  page= $('#sub-'+showid).attr('data-page');
  		if(data.pageTotal < page || isNaN(data.pageIndex)){
				$('#'+showid).html('<button class="whitebutton" style="display:block;width:100%;margin:10px auto;padding:8px 0" disabled>全部加载完毕</button>');
		}
	}

 }
 function nextPage(page,query,table,url){ 
 		$('#sub-'+query).html('载入中...');
		var c = $('#lgy_footer_pl').attr('data-cid');
		var n = $('#lgy_footer_pl').attr('data-nid');

		var param = 'userId='+lgy.getvar('userid')+'&userName='+lgy.getvar('userName')+'&loginStamp='+lgy.getvar('rnd')+'&pageIndex='+page+'&pageSize='+lgy.pagesize;
		if(query == '_'+table+'-page'){
 			lgy.getjson('e/api/getNewsList.php?'+url+'&pageIndex='+page+'&pageSize='+lgy.pagesize,'newslist:page:'+table+':'+table+':'+url);
		}
 }
 